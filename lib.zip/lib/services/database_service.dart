import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Collection references
  static const String usersCollection = 'users';
  static const String clientsCollection = 'clients';
  static const String providersCollection = 'providers';
  static const String requestsCollection = 'service_requests';
  static const String bookingsCollection = 'bookings';
  static const String conversationsCollection = 'conversations';
  static const String messagesCollection = 'messages';
  static const String reviewsCollection = 'reviews';

  // ──────────────────────────────────────────────────────────────────────────
  // USER OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  /// Save user basic information
  static Future<void> saveUserData({
    required String userId,
    required String phoneNumber,
    required String displayName,
    required bool isClient,
    required String nidNumber,
    required String dateOfBirth,
    required String fatherName,
    required String motherName,
    required String address,
  }) async {
    try {
      final userData = {
        'userId': userId,
        'phoneNumber': phoneNumber,
        'displayName': displayName,
        'isClient': isClient,
        'userType': isClient ? 'client' : 'provider',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'isActive': true,
      };

      // Save to users collection
      await _firestore.collection(usersCollection).doc(userId).set(userData);

      // Save to specific role collection
      final roleCollection = isClient ? clientsCollection : providersCollection;
      final roleData = {
        ...userData,
        'nidNumber': nidNumber,
        'dateOfBirth': dateOfBirth,
        'fatherName': fatherName,
        'motherName': motherName,
        'address': address,
        'profileComplete': true,
      };

      await _firestore.collection(roleCollection).doc(userId).set(roleData);
    } catch (e) {
      throw Exception('Failed to save user data: $e');
    }
  }

  /// Update user profile
  static Future<void> updateUserProfile({
    required String userId,
    required Map<String, dynamic> updates,
  }) async {
    try {
      updates['updatedAt'] = FieldValue.serverTimestamp();

      await _firestore.collection(usersCollection).doc(userId).update(updates);

      // Also update the role-specific collection
      // This will be determined by querying the user first
      final userDoc = await _firestore
          .collection(usersCollection)
          .doc(userId)
          .get();
      if (userDoc.exists) {
        final userType = userDoc['userType'] as String;
        final roleCollection = userType == 'client'
            ? clientsCollection
            : providersCollection;
        await _firestore.collection(roleCollection).doc(userId).update(updates);
      }
    } catch (e) {
      throw Exception('Failed to update user profile: $e');
    }
  }

  /// Get user data
  static Future<Map<String, dynamic>?> getUserData(String userId) async {
    try {
      final doc = await _firestore
          .collection(usersCollection)
          .doc(userId)
          .get();
      return doc.data();
    } catch (e) {
      throw Exception('Failed to fetch user data: $e');
    }
  }

  /// Get user by phone number
  static Future<Map<String, dynamic>?> getUserByPhoneNumber(
    String phoneNumber,
  ) async {
    try {
      final snapshot = await _firestore
          .collection(usersCollection)
          .where('phoneNumber', isEqualTo: phoneNumber)
          .limit(1)
          .get();

      if (snapshot.docs.isNotEmpty) {
        return snapshot.docs.first.data();
      }
      return null;
    } catch (e) {
      throw Exception('Failed to fetch user by phone: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // CLIENT-SPECIFIC OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  /// Get client profile
  static Future<Map<String, dynamic>?> getClientProfile(String userId) async {
    try {
      final doc = await _firestore
          .collection(clientsCollection)
          .doc(userId)
          .get();
      return doc.data();
    } catch (e) {
      throw Exception('Failed to fetch client profile: $e');
    }
  }

  /// Update client profile
  static Future<void> updateClientProfile({
    required String userId,
    required Map<String, dynamic> updates,
  }) async {
    try {
      updates['updatedAt'] = FieldValue.serverTimestamp();
      await _firestore
          .collection(clientsCollection)
          .doc(userId)
          .update(updates);
    } catch (e) {
      throw Exception('Failed to update client profile: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // PROVIDER-SPECIFIC OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  /// Get provider profile
  static Future<Map<String, dynamic>?> getProviderProfile(String userId) async {
    try {
      final doc = await _firestore
          .collection(providersCollection)
          .doc(userId)
          .get();
      return doc.data();
    } catch (e) {
      throw Exception('Failed to fetch provider profile: $e');
    }
  }

  /// Update provider profile
  static Future<void> updateProviderProfile({
    required String userId,
    required Map<String, dynamic> updates,
  }) async {
    try {
      updates['updatedAt'] = FieldValue.serverTimestamp();
      await _firestore
          .collection(providersCollection)
          .doc(userId)
          .update(updates);
    } catch (e) {
      throw Exception('Failed to update provider profile: $e');
    }
  }

  /// Get all providers by service type
  static Future<List<Map<String, dynamic>>> getProvidersByServiceType(
    String serviceType,
  ) async {
    try {
      final snapshot = await _firestore
          .collection(providersCollection)
          .where('serviceType', isEqualTo: serviceType)
          .where('isActive', isEqualTo: true)
          .get();

      return snapshot.docs.map((doc) => doc.data()).toList();
    } catch (e) {
      throw Exception('Failed to fetch providers: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // USER ACTIVITY/STATUS OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  /// Set user online/offline status
  static Future<void> setUserStatus({
    required String userId,
    required bool isOnline,
  }) async {
    try {
      await _firestore.collection(usersCollection).doc(userId).update({
        'isOnline': isOnline,
        'lastActive': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      throw Exception('Failed to update user status: $e');
    }
  }

  /// Deactivate user account
  static Future<void> deactivateUserAccount(String userId) async {
    try {
      await _firestore.collection(usersCollection).doc(userId).update({
        'isActive': false,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Also deactivate in role-specific collection
      final userDoc = await _firestore
          .collection(usersCollection)
          .doc(userId)
          .get();
      if (userDoc.exists) {
        final userType = userDoc['userType'] as String;
        final roleCollection = userType == 'client'
            ? clientsCollection
            : providersCollection;
        await _firestore.collection(roleCollection).doc(userId).update({
          'isActive': false,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (e) {
      throw Exception('Failed to deactivate account: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // BATCH OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  /// Delete user data (should be called when user account is deleted)
  static Future<void> deleteUserData(String userId) async {
    try {
      WriteBatch batch = _firestore.batch();

      // Delete from users collection
      batch.delete(_firestore.collection(usersCollection).doc(userId));

      // Determine user type and delete from role collection
      final userDoc = await _firestore
          .collection(usersCollection)
          .doc(userId)
          .get();
      if (userDoc.exists) {
        final userType = userDoc['userType'] as String;
        final roleCollection = userType == 'client'
            ? clientsCollection
            : providersCollection;
        batch.delete(_firestore.collection(roleCollection).doc(userId));
      }

      await batch.commit();
    } catch (e) {
      throw Exception('Failed to delete user data: $e');
    }
  }

  /// Check if user exists
  static Future<bool> userExists(String userId) async {
    try {
      final doc = await _firestore
          .collection(usersCollection)
          .doc(userId)
          .get();
      return doc.exists;
    } catch (e) {
      throw Exception('Failed to check user existence: $e');
    }
  }

  /// Get user count by type
  static Future<int> getUserCountByType(String userType) async {
    try {
      final snapshot = await _firestore
          .collection(usersCollection)
          .where('userType', isEqualTo: userType)
          .count()
          .get();
      return snapshot.count ?? 0;
    } catch (e) {
      throw Exception('Failed to get user count: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // SERVICE REQUEST OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  static Future<void> createServiceRequest({
    required String clientId,
    required String category,
    required String description,
    required String location,
    required String budget,
    required bool isUrgent,
  }) async {
    try {
      await _firestore.collection(requestsCollection).add({
        'clientId': clientId,
        'category': category,
        'description': description,
        'location': location,
        'budget': budget,
        'isUrgent': isUrgent,
        'status': 'open',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      throw Exception('Failed to create service request: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> getClientRequests(
    String clientId,
  ) async {
    try {
      final snapshot = await _firestore
          .collection(requestsCollection)
          .where('clientId', isEqualTo: clientId)
          .orderBy('createdAt', descending: true)
          .get();

      return snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
    } catch (e) {
      throw Exception('Failed to fetch client requests: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> getOpenRequests({
    String? category,
  }) async {
    try {
      Query<Map<String, dynamic>> query = _firestore
          .collection(requestsCollection)
          .where('status', isEqualTo: 'open');

      if (category != null && category.trim().isNotEmpty) {
        query = query.where('category', isEqualTo: category);
      }

      final snapshot = await query.orderBy('createdAt', descending: true).get();

      return snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
    } catch (e) {
      throw Exception('Failed to fetch open requests: $e');
    }
  }

  static Future<Map<String, dynamic>> getClientStats(String clientId) async {
    try {
      final activeSnapshot = await _firestore
          .collection(requestsCollection)
          .where('clientId', isEqualTo: clientId)
          .where('status', whereIn: ['open', 'accepted', 'in_progress'])
          .get();

      final completedSnapshot = await _firestore
          .collection(requestsCollection)
          .where('clientId', isEqualTo: clientId)
          .where('status', isEqualTo: 'completed')
          .get();

      return {
        'active': activeSnapshot.docs.length,
        'completed': completedSnapshot.docs.length,
      };
    } catch (e) {
      throw Exception('Failed to fetch client stats: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // BOOKING OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  static Future<void> createBooking({
    required String requestId,
    required String clientId,
    required String providerId,
    required String agreedPrice,
  }) async {
    try {
      final bookingRef = _firestore.collection(bookingsCollection).doc();

      await bookingRef.set({
        'requestId': requestId,
        'clientId': clientId,
        'providerId': providerId,
        'agreedPrice': agreedPrice,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      if (requestId.isNotEmpty) {
        await _firestore.collection(requestsCollection).doc(requestId).update({
          'status': 'accepted',
          'providerId': providerId,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (e) {
      throw Exception('Failed to create booking: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> getProviderBookings(
    String providerId,
  ) async {
    try {
      final snapshot = await _firestore
          .collection(bookingsCollection)
          .where('providerId', isEqualTo: providerId)
          .orderBy('createdAt', descending: true)
          .get();

      return snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
    } catch (e) {
      throw Exception('Failed to fetch provider bookings: $e');
    }
  }

  static Future<void> updateBookingStatus({
    required String bookingId,
    required String status,
  }) async {
    try {
      await _firestore.collection(bookingsCollection).doc(bookingId).update({
        'status': status,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      final bookingDoc = await _firestore
          .collection(bookingsCollection)
          .doc(bookingId)
          .get();
      final requestId = bookingDoc.data()?['requestId'] as String?;
      if (requestId != null && requestId.isNotEmpty) {
        await _firestore.collection(requestsCollection).doc(requestId).update({
          'status': status,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (e) {
      throw Exception('Failed to update booking status: $e');
    }
  }

  static Future<Map<String, dynamic>> getProviderStats(
    String providerId,
  ) async {
    try {
      final activeSnapshot = await _firestore
          .collection(bookingsCollection)
          .where('providerId', isEqualTo: providerId)
          .where('status', whereIn: ['confirmed', 'in_progress'])
          .get();

      final allSnapshot = await _firestore
          .collection(bookingsCollection)
          .where('providerId', isEqualTo: providerId)
          .get();

      double totalEarnings = 0;
      for (final doc in allSnapshot.docs) {
        if ((doc.data()['status'] ?? '') == 'completed') {
          totalEarnings += _toDouble(doc.data()['agreedPrice']);
        }
      }

      return {
        'activeJobs': activeSnapshot.docs.length,
        'totalJobs': allSnapshot.docs.length,
        'totalEarnings': totalEarnings,
      };
    } catch (e) {
      throw Exception('Failed to fetch provider stats: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // CONVERSATION + MESSAGE OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  static Future<String> getOrCreateConversation({
    required String clientId,
    required String providerId,
  }) async {
    try {
      final existing = await _firestore
          .collection(conversationsCollection)
          .where('clientId', isEqualTo: clientId)
          .where('providerId', isEqualTo: providerId)
          .limit(1)
          .get();

      if (existing.docs.isNotEmpty) {
        return existing.docs.first.id;
      }

      final docRef = _firestore.collection(conversationsCollection).doc();
      await docRef.set({
        'clientId': clientId,
        'providerId': providerId,
        'lastMessage': '',
        'lastMessageAt': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return docRef.id;
    } catch (e) {
      throw Exception('Failed to create conversation: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> getUserConversations(
    String userId,
    bool isClient,
  ) async {
    try {
      final field = isClient ? 'clientId' : 'providerId';
      final snapshot = await _firestore
          .collection(conversationsCollection)
          .where(field, isEqualTo: userId)
          .orderBy('lastMessageAt', descending: true)
          .get();

      return snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
    } catch (e) {
      throw Exception('Failed to fetch conversations: $e');
    }
  }

  static Future<void> sendMessage({
    required String conversationId,
    required String senderId,
    required String content,
  }) async {
    try {
      await _firestore
          .collection(conversationsCollection)
          .doc(conversationId)
          .collection(messagesCollection)
          .add({
            'senderId': senderId,
            'content': content,
            'messageType': 'text',
            'readBy': [senderId],
            'createdAt': FieldValue.serverTimestamp(),
          });

      await _firestore
          .collection(conversationsCollection)
          .doc(conversationId)
          .update({
            'lastMessage': content,
            'lastMessageAt': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
    } catch (e) {
      throw Exception('Failed to send message: $e');
    }
  }

  static Stream<List<Map<String, dynamic>>> streamMessages(
    String conversationId,
  ) {
    return _firestore
        .collection(conversationsCollection)
        .doc(conversationId)
        .collection(messagesCollection)
        .orderBy('createdAt')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => {'id': doc.id, ...doc.data()})
              .toList(),
        );
  }

  static Future<void> markMessagesAsRead({
    required String conversationId,
    required String readerId,
  }) async {
    try {
      final snapshot = await _firestore
          .collection(conversationsCollection)
          .doc(conversationId)
          .collection(messagesCollection)
          .where('senderId', isNotEqualTo: readerId)
          .get();

      final batch = _firestore.batch();
      for (final doc in snapshot.docs) {
        final readBy = List<String>.from(doc.data()['readBy'] ?? []);
        if (!readBy.contains(readerId)) {
          batch.update(doc.reference, {
            'readBy': [...readBy, readerId],
          });
        }
      }
      await batch.commit();
    } catch (e) {
      throw Exception('Failed to mark messages as read: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // REVIEW OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  static Future<void> createReview({
    required String bookingId,
    required String clientId,
    required String providerId,
    required int rating,
    required String reviewText,
  }) async {
    try {
      await _firestore.collection(reviewsCollection).add({
        'bookingId': bookingId,
        'clientId': clientId,
        'providerId': providerId,
        'rating': rating.toDouble(),
        'reviewText': reviewText,
        'createdAt': FieldValue.serverTimestamp(),
      });

      final reviews = await _firestore
          .collection(reviewsCollection)
          .where('providerId', isEqualTo: providerId)
          .get();

      if (reviews.docs.isNotEmpty) {
        double sum = 0;
        for (final doc in reviews.docs) {
          sum += _toDouble(doc.data()['rating']);
        }
        final avg = sum / reviews.docs.length;
        await _firestore.collection(providersCollection).doc(providerId).set({
          'ratingAvg': avg,
          'totalReviews': reviews.docs.length,
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    } catch (e) {
      throw Exception('Failed to create review: $e');
    }
  }

  static Future<List<Map<String, dynamic>>> getProviderReviews(
    String providerId,
  ) async {
    try {
      final snapshot = await _firestore
          .collection(reviewsCollection)
          .where('providerId', isEqualTo: providerId)
          .orderBy('createdAt', descending: true)
          .get();

      List<Map<String, dynamic>> output = [];
      for (final doc in snapshot.docs) {
        final data = doc.data();
        final clientId = data['clientId'] as String? ?? '';

        String name = 'Client';
        if (clientId.isNotEmpty) {
          final clientDoc = await _firestore
              .collection(clientsCollection)
              .doc(clientId)
              .get();
          name = clientDoc.data()?['displayName'] as String? ?? 'Client';
        }

        final parts = name.split(' ');
        final initials = parts.length >= 2
            ? '${parts.first[0]}${parts.last[0]}'.toUpperCase()
            : name.isNotEmpty
            ? name[0].toUpperCase()
            : 'C';

        output.add({
          'id': doc.id,
          'name': name,
          'initials': initials,
          'date': _formatDate(data['createdAt']),
          'rating': _toDouble(data['rating']),
          'text': (data['reviewText'] ?? '').toString(),
        });
      }

      return output;
    } catch (e) {
      throw Exception('Failed to fetch provider reviews: $e');
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // SESSION/CLEANUP OPERATIONS
  // ──────────────────────────────────────────────────────────────────────────

  static Future<void> signOutCleanup(String userId) async {
    try {
      await _firestore.collection(usersCollection).doc(userId).set({
        'isOnline': false,
        'lastActive': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {
      // Avoid blocking sign-out for non-critical cleanup updates.
    }
  }

  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    if (value is String) {
      final cleaned = value.replaceAll(RegExp(r'[^0-9.]'), '');
      return double.tryParse(cleaned) ?? 0;
    }
    return 0;
  }

  static String _formatDate(dynamic timestamp) {
    if (timestamp is! Timestamp) return '';
    final dt = timestamp.toDate();
    final y = dt.year.toString().padLeft(4, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final d = dt.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }
}
