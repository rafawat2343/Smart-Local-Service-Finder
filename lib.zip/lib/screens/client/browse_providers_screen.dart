import 'package:flutter/material.dart';
import '../../utils/app_colors.dart';
import '../../widgets/shared_widgets.dart';
import '../provider/provider_profile_screen.dart';

class BrowseProvidersScreen extends StatelessWidget {
  const BrowseProvidersScreen({super.key});

  static const _providers = [
    {
      'initials': 'RS',
      'name': 'Rahim Sheikh',
      'specialty': 'Master Electrician',
      'exp': '8 yrs',
      'rating': 4.8,
      'reviews': 142,
      'distance': 2.3,
      'available': true,
      'price': '500',
      'jobs': 230,
    },
    {
      'initials': 'KA',
      'name': 'Karim Ahmed',
      'specialty': 'Electrician',
      'exp': '5 yrs',
      'rating': 4.7,
      'reviews': 98,
      'distance': 3.5,
      'available': true,
      'price': '400',
      'jobs': 112,
    },
    {
      'initials': 'FH',
      'name': 'Faruk Hossain',
      'specialty': 'Senior Electrician',
      'exp': '12 yrs',
      'rating': 4.9,
      'reviews': 234,
      'distance': 4.1,
      'available': false,
      'price': '700',
      'jobs': 390,
    },
    {
      'initials': 'SA',
      'name': 'Salam Ali',
      'specialty': 'Electrician',
      'exp': '6 yrs',
      'rating': 4.6,
      'reviews': 67,
      'distance': 5.2,
      'available': true,
      'price': '450',
      'jobs': 89,
    },
  ];

  static const _filters = [
    'All',
    'Top Rated',
    'Nearest',
    'Available',
    'Budget',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BackgroundWatermark(
        child: Column(
          children: [
            // ── Header ───────────────────────────────────────────────────
            Container(
              color: AppColors.navy,
              padding: EdgeInsets.fromLTRB(
                20,
                MediaQuery.of(context).padding.top + 12,
                20,
                16,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const NavBackButton(),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Electricians',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                letterSpacing: -0.3,
                              ),
                            ),
                            Text(
                              'Near your location',
                              style: TextStyle(
                                color: Colors.white54,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.tune_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  // Filters
                  SizedBox(
                    height: 32,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _filters.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, i) {
                        final selected = i == 0;
                        return Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: selected
                                ? Colors.white
                                : Colors.white.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                              color: selected
                                  ? Colors.white
                                  : Colors.white.withOpacity(0.2),
                            ),
                          ),
                          child: Text(
                            _filters[i],
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: selected
                                  ? AppColors.navy
                                  : Colors.white.withOpacity(0.8),
                              letterSpacing: 0.1,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),

            // ── Results ──────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 10),
              child: Row(
                children: [
                  Text(
                    '${_providers.length} providers found',
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Spacer(),
                  const Icon(
                    Icons.swap_vert_rounded,
                    size: 15,
                    color: AppColors.accent,
                  ),
                  const SizedBox(width: 4),
                  const Text(
                    'Rating',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.accent,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),

            // ── List ─────────────────────────────────────────────────────
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                itemCount: _providers.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) {
                  final p = _providers[i];
                  final available = p['available'] as bool;
                  return GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ProviderProfileScreen(),
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Stack(
                                  children: [
                                    ProviderAvatar(
                                      initials: p['initials'] as String,
                                      size: 52,
                                    ),
                                    Positioned(
                                      bottom: 2,
                                      right: 2,
                                      child: Container(
                                        width: 11,
                                        height: 11,
                                        decoration: BoxDecoration(
                                          color: available
                                              ? AppColors.success
                                              : AppColors.textTertiary,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 2,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              p['name'] as String,
                                              style: const TextStyle(
                                                fontWeight: FontWeight.w700,
                                                fontSize: 14,
                                                color: AppColors.textPrimary,
                                              ),
                                            ),
                                          ),
                                          Text(
                                            '৳${p['price']}/hr',
                                            style: const TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w800,
                                              color: AppColors.navy,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '${p['specialty']} · ${p['exp']} exp',
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        children: [
                                          starRating(
                                            p['rating'] as double,
                                            size: 12,
                                          ),
                                          const SizedBox(width: 5),
                                          Text(
                                            '${p['rating']} (${p['reviews']})',
                                            style: const TextStyle(
                                              fontSize: 11,
                                              color: AppColors.textSecondary,
                                            ),
                                          ),
                                          const Spacer(),
                                          const Icon(
                                            Icons.location_on_outlined,
                                            size: 12,
                                            color: AppColors.textTertiary,
                                          ),
                                          Text(
                                            '${p['distance']} km',
                                            style: const TextStyle(
                                              fontSize: 11,
                                              color: AppColors.textTertiary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 9,
                            ),
                            decoration: const BoxDecoration(
                              color: AppColors.surfaceAlt,
                              borderRadius: BorderRadius.vertical(
                                bottom: Radius.circular(10),
                              ),
                              border: Border(
                                top: BorderSide(color: AppColors.divider),
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  available
                                      ? Icons.check_circle_rounded
                                      : Icons.cancel_outlined,
                                  size: 12,
                                  color: available
                                      ? AppColors.success
                                      : AppColors.textTertiary,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  available
                                      ? 'Available now'
                                      : 'Currently busy',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: available
                                        ? AppColors.success
                                        : AppColors.textTertiary,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const Spacer(),
                                Text(
                                  '${p['jobs']} jobs completed',
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: AppColors.textTertiary,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
