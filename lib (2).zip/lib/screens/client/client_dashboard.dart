import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../services/connectivity_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_colors.dart';
import '../../widgets/shared_widgets.dart';
import 'browse_electricians_screen.dart';
import 'browse_plumbers_screen.dart';
import 'browse_cleaners_screen.dart';
import 'browse_painters_screen.dart';
import '../shared/chat_screen.dart';
import 'client_notifications_screen.dart';
import 'client_profile_screen.dart';

class ClientDashboard extends StatefulWidget {
  const ClientDashboard({super.key});

  @override
  State<ClientDashboard> createState() => _ClientDashboardState();
}

class _ClientDashboardState extends State<ClientDashboard> {
  int _idx = 0;

  final List<Widget> _screens = const [
    _DashboardHome(),
    _RequestsScreen(),
    _ChatsListScreen(),
    ClientProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BackgroundWatermark(child: IndexedStack(index: _idx, children: _screens)),
      bottomNavigationBar: _CorpBottomNav(
        selectedIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
      ),
    );
  }
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────

class _CorpBottomNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onTap;

  const _CorpBottomNav({required this.selectedIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.home_outlined, Icons.home_rounded, 'Home'),
      (Icons.assignment_outlined, Icons.assignment_rounded, 'Requests'),
      (Icons.chat_bubble_outline_rounded, Icons.chat_bubble_rounded, 'Chats'),
      (Icons.person_outline_rounded, Icons.person_rounded, 'Profile'),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 58,
          child: Row(
            children: List.generate(items.length, (i) {
              final selected = i == selectedIndex;
              return Expanded(
                child: GestureDetector(
                  onTap: () => onTap(i),
                  behavior: HitTestBehavior.opaque,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        selected ? items[i].$2 : items[i].$1,
                        size: 22,
                        color: selected
                            ? AppColors.navy
                            : AppColors.textTertiary,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        items[i].$3,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: selected
                              ? FontWeight.w700
                              : FontWeight.w400,
                          color: selected
                              ? AppColors.navy
                              : AppColors.textTertiary,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ─── Dashboard Home ───────────────────────────────────────────────────────────

class _DashboardHome extends StatefulWidget {
  const _DashboardHome();

  @override
  State<_DashboardHome> createState() => _DashboardHomeState();
}

class _DashboardHomeState extends State<_DashboardHome> {
  int _active = 0;
  int _completed = 0;
  int _providerCount = 0;
  String _userName = 'User';
  String _searchQuery = '';
  bool _isLoading = true;
  int _unreadNotifications = 0;
  List<Map<String, dynamic>> _recentRequests = [];

  static final _categories = [
    (Icons.bolt_rounded, 'Electrician', Color(0xFFC8880A), Color(0xFFFAF3E0), () => const BrowseElectriciansScreen()),
    (Icons.plumbing_rounded, 'Plumber', Color(0xFF1A5A7A), Color(0xFFE6F1F7), () => const BrowsePlumbersScreen()),
    (
      Icons.cleaning_services_rounded,
      'Cleaner',
      Color(0xFF4A1A7A),
      Color(0xFFEFE6F7),
      () => const BrowseCleanersScreen(),
    ),
    (
      Icons.format_paint_rounded,
      'Painter',
      Color(0xFF7A1A1A),
      Color(0xFFF7E6E6),
      () => const BrowsePaintersScreen(),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  List<(IconData, String, Color, Color, Widget Function())> get _filteredCategories {
    if (_searchQuery.isEmpty) return _categories;
    return _categories.where((c) => c.$2.toLowerCase().contains(_searchQuery.toLowerCase())).toList();
  }

  Future<void> _loadStats() async {
    if (mounted) setState(() => _isLoading = true);
    final hasNet = await ConnectivityService.hasInternet();
    if (!hasNet) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    final userId = AuthService.getCurrentUserId();
    if (userId == null) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    try {
      // Load profile from Firestore for the real name
      final clientProfile = await DatabaseService.getClientProfile(userId);
      final name = clientProfile?['displayName']
          ?? AuthService.getCurrentUserDisplayName()
          ?? 'User';

      final stats = await DatabaseService.getClientStats(userId);
      final provCount = await DatabaseService.getUserCountByType('provider');

      // Load requests — may fail if composite index not yet created
      List<Map<String, dynamic>> requests = [];
      try {
        requests = await DatabaseService.getClientRequests(userId);
      } catch (_) {
        // Index might not exist yet — will show empty list
      }

      // Count admin-feedback notifications (non-empty adminFeedback)
      int notifCount = 0;
      try {
        final reports = await DatabaseService.getClientReports(userId);
        notifCount = reports
            .where((r) =>
                (r['adminFeedback'] ?? '').toString().trim().isNotEmpty ||
                r['status'] == 'reviewed')
            .length;
      } catch (_) {}

      if (mounted) {
        setState(() {
          _active = stats['active'] ?? 0;
          _completed = stats['completed'] ?? 0;
          _providerCount = provCount;
          _userName = name;
          _recentRequests = requests.take(5).toList();
          _unreadNotifications = notifCount;
        });
      }
    } catch (_) {
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _openNotifications() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ClientNotificationsScreen()),
    );
    _loadStats();
  }

  void _showCreateRequestSheet() {
    final descCtrl = TextEditingController();
    final locationCtrl = TextEditingController();
    final budgetCtrl = TextEditingController();
    String selectedCategory = 'Electrician';
    bool isUrgent = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            padding: EdgeInsets.fromLTRB(24, 8, 24, MediaQuery.of(ctx).padding.bottom + 20),
            decoration: const BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Center(child: Container(width: 36, height: 4, margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                const Text('Create Service Request', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: 20),

                const Text('CATEGORY', style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.border)),
                  child: DropdownButtonFormField<String>(
                    value: selectedCategory,
                    decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12)),
                    isExpanded: true, dropdownColor: AppColors.surface, borderRadius: BorderRadius.circular(8),
                    items: ['Electrician', 'Plumber', 'Cleaner', 'Painter'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                    onChanged: (v) => setSheetState(() => selectedCategory = v ?? 'Electrician'),
                  ),
                ),
                const SizedBox(height: 14),

                const Text('DESCRIPTION *', style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                const SizedBox(height: 8),
                TextField(
                  controller: descCtrl, maxLines: 3,
                  decoration: InputDecoration(hintText: 'Describe what you need...', hintStyle: const TextStyle(color: AppColors.textTertiary, fontSize: 13),
                    filled: true, fillColor: AppColors.surfaceAlt,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.navy, width: 1.5)),
                  ),
                ),
                const SizedBox(height: 14),

                const Text('LOCATION *', style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                const SizedBox(height: 8),
                TextField(
                  controller: locationCtrl,
                  decoration: InputDecoration(hintText: 'e.g. Mirpur, Dhaka', hintStyle: const TextStyle(color: AppColors.textTertiary, fontSize: 13),
                    prefixIcon: const Padding(padding: EdgeInsets.only(left: 14, right: 8), child: Icon(Icons.location_on_outlined, size: 18, color: AppColors.textSecondary)),
                    prefixIconConstraints: const BoxConstraints(),
                    filled: true, fillColor: AppColors.surfaceAlt,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.navy, width: 1.5)),
                  ),
                ),
                const SizedBox(height: 14),

                Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('BUDGET (৳)', style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: budgetCtrl, keyboardType: TextInputType.number,
                      decoration: InputDecoration(hintText: '500', hintStyle: const TextStyle(color: AppColors.textTertiary, fontSize: 13),
                        filled: true, fillColor: AppColors.surfaceAlt,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.navy, width: 1.5)),
                      ),
                    ),
                  ])),
                  const SizedBox(width: 14),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('URGENT', style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                    const SizedBox(height: 8),
                    GestureDetector(
                      onTap: () => setSheetState(() => isUrgent = !isUrgent),
                      child: Container(
                        width: 52, height: 48,
                        decoration: BoxDecoration(
                          color: isUrgent ? AppColors.urgentBg : AppColors.surfaceAlt,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: isUrgent ? AppColors.urgent : AppColors.border),
                        ),
                        child: Icon(Icons.bolt_rounded, color: isUrgent ? AppColors.urgent : AppColors.textTertiary, size: 22),
                      ),
                    ),
                  ]),
                ]),
                const SizedBox(height: 24),

                SizedBox(width: double.infinity, height: 48, child: ElevatedButton(
                  onPressed: () async {
                    if (descCtrl.text.trim().isEmpty || locationCtrl.text.trim().isEmpty) {
                      ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Please fill description and location')));
                      return;
                    }
                    final userId = AuthService.getCurrentUserId();
                    if (userId == null) return;
                    await DatabaseService.createServiceRequest(
                      clientId: userId,
                      category: selectedCategory,
                      description: descCtrl.text.trim(),
                      location: locationCtrl.text.trim(),
                      budget: budgetCtrl.text.trim(),
                      isUrgent: isUrgent,
                    );
                    if (ctx.mounted) {
                      Navigator.pop(ctx);
                      _loadStats(); // Refresh
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Request created!'), backgroundColor: AppColors.success),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.accent, elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  child: const Text('Submit Request', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white)),
                )),
                const SizedBox(height: 10),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.navy),
      );
    }
    return RefreshIndicator(
      onRefresh: _loadStats,
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
        // ── App Bar ──────────────────────────────────────────────────────
        SliverToBoxAdapter(
          child: Container(
            color: AppColors.navy,
            padding: EdgeInsets.fromLTRB(
              20,
              MediaQuery.of(context).padding.top + 14,
              20,
              24,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Good morning,',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.55),
                            fontSize: 12,
                            letterSpacing: 0.3,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _userName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.4,
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: _openNotifications,
                      child: Stack(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(
                              Icons.notifications_outlined,
                              color: Colors.white,
                              size: 20,
                            ),
                          ),
                          if (_unreadNotifications > 0)
                            Positioned(
                              top: 4,
                              right: 4,
                              child: Container(
                                constraints: const BoxConstraints(
                                  minWidth: 16,
                                  minHeight: 16,
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.accent,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: AppColors.navy,
                                    width: 1.5,
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  _unreadNotifications > 9
                                      ? '9+'
                                      : '$_unreadNotifications',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                // Search bar
                Container(
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: TextField(
                    onChanged: (v) => setState(() => _searchQuery = v),
                    decoration: const InputDecoration(
                      hintText: 'Search services or providers...',
                      hintStyle: TextStyle(
                        color: AppColors.textTertiary,
                        fontSize: 13,
                      ),
                      prefixIcon: Icon(
                        Icons.search_rounded,
                        color: AppColors.textTertiary,
                        size: 20,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 12),
                      isDense: true,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        // ── Stats strip ──────────────────────────────────────────────────
        SliverToBoxAdapter(
          child: Container(
            color: AppColors.navyDark,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            child: Row(
              children: [
                _StatChip(label: 'Active', value: '$_active'),
                Container(
                  width: 1,
                  height: 28,
                  color: Colors.white.withOpacity(0.12),
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                ),
                _StatChip(label: 'Completed', value: '$_completed'),
                Container(
                  width: 1,
                  height: 28,
                  color: Colors.white.withOpacity(0.12),
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                ),
                _StatChip(label: 'Providers', value: '$_providerCount'),
              ],
            ),
          ),
        ),

        // ── Categories ───────────────────────────────────────────────────
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
            child: SectionHeader(
              title: 'Service Categories',
              action: _searchQuery.isNotEmpty ? 'View all' : '',
              onAction: () => setState(() => _searchQuery = ''),
            ),
          ),
        ),

        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate((context, i) {
              final cat = _filteredCategories[i];
              return GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => cat.$5(),
                  ),
                ),
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: cat.$4,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(cat.$1, size: 22, color: cat.$3),
                      ),
                      const SizedBox(height: 9),
                      Text(
                        cat.$2,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                          letterSpacing: 0.1,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }, childCount: _filteredCategories.length),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.5,
            ),
          ),
        ),

        // ── Recent Requests ──────────────────────────────────────────────
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
            child: Row(
              children: [
                const Text('Recent Requests', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary, letterSpacing: -0.3)),
                const Spacer(),
                GestureDetector(
                  onTap: _showCreateRequestSheet,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.accent, borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.add_rounded, size: 14, color: Colors.white),
                      SizedBox(width: 4),
                      Text('New Request', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ),

        if (_recentRequests.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Center(child: Text('No requests yet. Tap "New Request" to create one.',
                  style: TextStyle(fontSize: 13, color: AppColors.textTertiary))),
            ),
          )
        else
          SliverList(
            delegate: SliverChildBuilderDelegate((context, i) {
              final r = _recentRequests[i];
              return Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: _RequestCard(
                  category: r['category'] ?? 'Service',
                  icon: Icons.bolt_rounded,
                  iconColor: const Color(0xFFC8880A),
                  iconBg: const Color(0xFFFAF3E0),
                  description: r['description'] ?? '',
                  location: r['location'] ?? '',
                  isUrgent: r['isUrgent'] == true,
                  status: (r['status'] ?? 'open').toString().toUpperCase(),
                  timeAgo: '',
                ),
              );
            }, childCount: _recentRequests.length),
          ),

        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  const _StatChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.5),
            fontSize: 10,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }
}

// ─── Request Card ─────────────────────────────────────────────────────────────

class _RequestCard extends StatelessWidget {
  final String category;
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String description;
  final String location;
  final bool isUrgent;
  final String status;
  final String timeAgo;

  const _RequestCard({
    required this.category,
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.description,
    required this.location,
    required this.isUrgent,
    required this.status,
    required this.timeAgo,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isUrgent
              ? AppColors.urgent.withOpacity(0.35)
              : AppColors.border,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.navy.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: iconBg,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(icon, color: iconColor, size: 18),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      category,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const Spacer(),
                    if (isUrgent)
                      StatusBadge(
                        label: 'URGENT',
                        color: AppColors.urgent,
                        bgColor: AppColors.urgentBg,
                        icon: Icons.bolt_rounded,
                      ),
                    const SizedBox(width: 8),
                    StatusBadge(
                      label: status.toUpperCase(),
                      color: AppColors.success,
                      bgColor: AppColors.successBg,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.textSecondary,
                    height: 1.55,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: const BoxDecoration(
              color: AppColors.surfaceAlt,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(10)),
              border: Border(top: BorderSide(color: AppColors.divider)),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.location_on_outlined,
                  size: 13,
                  color: AppColors.textSecondary,
                ),
                const SizedBox(width: 4),
                Text(
                  location,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
                const Spacer(),
                Text(
                  timeAgo,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textTertiary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Requests Screen ──────────────────────────────────────────────────────────

class _RequestsScreen extends StatefulWidget {
  const _RequestsScreen();

  @override
  State<_RequestsScreen> createState() => _RequestsScreenState();
}

class _RequestsScreenState extends State<_RequestsScreen> {
  List<Map<String, dynamic>> _requests = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  Future<void> _loadRequests() async {
    final userId = AuthService.getCurrentUserId();
    if (userId == null) { setState(() => _loading = false); return; }

    try {
      final reqs = await DatabaseService.getClientRequests(userId);
      if (mounted) setState(() { _requests = reqs; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('My Requests'),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.navy))
          : _requests.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.assignment_outlined, size: 52, color: AppColors.textTertiary),
                      SizedBox(height: 14),
                      Text('No requests yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
                      SizedBox(height: 4),
                      Text('Your service requests will appear here', style: TextStyle(fontSize: 13, color: AppColors.textTertiary)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadRequests,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _requests.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, i) {
                      final r = _requests[i];
                      final status = r['status'] ?? 'open';
                      return _RequestCard(
                        category: r['category'] ?? 'Service',
                        icon: Icons.work_outline_rounded,
                        iconColor: AppColors.navy,
                        iconBg: AppColors.navyLight,
                        description: r['description'] ?? '',
                        location: r['location'] ?? '',
                        isUrgent: r['isUrgent'] == true,
                        status: status,
                        timeAgo: '',
                      );
                    },
                  ),
                ),
    );
  }
}

// ─── Chats List ───────────────────────────────────────────────────────────────

class _ChatsListScreen extends StatefulWidget {
  const _ChatsListScreen();

  @override
  State<_ChatsListScreen> createState() => _ChatsListScreenState();
}

class _ChatsListScreenState extends State<_ChatsListScreen> {
  List<Map<String, dynamic>> _conversations = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadConversations();
  }

  Future<void> _loadConversations() async {
    final userId = AuthService.getCurrentUserId();
    if (userId == null) { setState(() => _loading = false); return; }

    try {
      final convs = await DatabaseService.getUserConversations(userId, true);
      // For each conversation, fetch the provider name
      List<Map<String, dynamic>> enriched = [];
      for (final conv in convs) {
        final providerId = conv['providerId'] ?? '';
        Map<String, dynamic>? providerData;
        if (providerId.isNotEmpty) {
          providerData = await DatabaseService.getProviderProfile(providerId);
        }
        final name = providerData?['displayName'] ?? 'Provider';
        final parts = name.split(' ');
        final initials = parts.length >= 2
            ? '${parts.first[0]}${parts.last[0]}'.toUpperCase()
            : name.isNotEmpty ? name[0].toUpperCase() : 'P';
        enriched.add({...conv, '_name': name, '_initials': initials});
      }
      if (mounted) setState(() { _conversations = enriched; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Messages'),
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.navy))
          : _conversations.isEmpty
              ? const Center(
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.chat_bubble_outline_rounded, size: 52, color: AppColors.textTertiary),
                    SizedBox(height: 14),
                    Text('No messages yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
                    SizedBox(height: 4),
                    Text('Start chatting with a provider', style: TextStyle(fontSize: 13, color: AppColors.textTertiary)),
                  ]),
                )
              : RefreshIndicator(
                  onRefresh: _loadConversations,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _conversations.length,
                    itemBuilder: (context, i) {
                      final c = _conversations[i];
                      return _ChatRow(
                        initials: c['_initials'] ?? 'P',
                        name: c['_name'] ?? 'Provider',
                        preview: 'Tap to continue chat',
                        time: '',
                        unread: 0,
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => ChatScreen(
                            conversationId: c['id'] ?? '',
                            otherUserName: c['_name'] ?? 'Provider',
                            otherUserInitials: c['_initials'] ?? 'P',
                          ),
                        )),
                      );
                    },
                  ),
                ),
    );
  }
}

class _ChatRow extends StatelessWidget {
  final String initials;
  final String name;
  final String preview;
  final String time;
  final int unread;
  final VoidCallback onTap;

  const _ChatRow({
    required this.initials,
    required this.name,
    required this.preview,
    required this.time,
    required this.unread,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            ProviderAvatar(initials: initials, size: 44),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    preview,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  time,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textTertiary,
                  ),
                ),
                if (unread > 0) ...[
                  const SizedBox(height: 5),
                  Container(
                    width: 18,
                    height: 18,
                    decoration: const BoxDecoration(
                      color: AppColors.accent,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(
                        '$unread',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
