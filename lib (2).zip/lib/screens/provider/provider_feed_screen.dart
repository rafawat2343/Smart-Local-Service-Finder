import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../services/connectivity_service.dart';
import '../../services/database_service.dart';
import '../../utils/app_colors.dart';
import '../../widgets/shared_widgets.dart';
import '../shared/chat_screen.dart';
import 'provider_profile_screen.dart';

class ProviderFeedScreen extends StatefulWidget {
  const ProviderFeedScreen({super.key});

  @override
  State<ProviderFeedScreen> createState() => _ProviderFeedScreenState();
}

class _ProviderFeedScreenState extends State<ProviderFeedScreen> {
  int _idx = 0;

  final List<Widget> _screens = const [
    _FeedHome(),
    _MyJobsScreen(),
    _ChatsScreen(),
    ProviderProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BackgroundWatermark(
        child: IndexedStack(index: _idx, children: _screens),
      ),
      bottomNavigationBar: _CorpNav(
        selectedIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
      ),
    );
  }
}

class _CorpNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onTap;
  const _CorpNav({required this.selectedIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.work_outline_rounded, Icons.work_rounded, 'Jobs'),
      (
        Icons.check_circle_outline_rounded,
        Icons.check_circle_rounded,
        'My Jobs',
      ),
      (Icons.chat_bubble_outline_rounded, Icons.chat_bubble_rounded, 'Chats'),
      (Icons.person_outline_rounded, Icons.person_rounded, 'Profile'),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 58,
          child: Row(
            children: List.generate(items.length, (i) {
              final selected = i == selectedIndex;
              return Expanded(
                child: GestureDetector(
                  onTap: () => onTap(i),
                  behavior: HitTestBehavior.opaque,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        selected ? items[i].$2 : items[i].$1,
                        size: 22,
                        color: selected
                            ? AppColors.accent
                            : AppColors.textTertiary,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        items[i].$3,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: selected
                              ? FontWeight.w700
                              : FontWeight.w400,
                          color: selected
                              ? AppColors.accent
                              : AppColors.textTertiary,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ─── Feed Home ────────────────────────────────────────────────────────────────

class _FeedHome extends StatefulWidget {
  const _FeedHome();

  @override
  State<_FeedHome> createState() => _FeedHomeState();
}

class _FeedHomeState extends State<_FeedHome> {
  bool _isOnline = true;
  bool _isLoading = true;
  List<Map<String, dynamic>> _jobs = [];
  String _providerName = 'Provider';
  String _providerInitials = 'P';
  String _providerLocation = '';
  String _providerSpecialty = '';
  int _todayJobs = 0;
  int _monthJobs = 0;
  String _earnings = '৳0';
  int _selectedFilter = 0;

  List<Map<String, dynamic>> get _filteredJobs {
    if (_selectedFilter == 0) return _jobs; // All Jobs
    if (_selectedFilter == 1) {
      // Nearby
      if (_providerLocation.trim().isEmpty) return _jobs;
      return _jobs.where((j) {
        final jobLocation = (j['location'] ?? '').toString().toLowerCase();
        final providerLocation = _providerLocation.toLowerCase();
        return jobLocation.contains(providerLocation) ||
            providerLocation.contains(jobLocation);
      }).toList();
    }
    if (_selectedFilter == 2) {
      // Urgent only
      return _jobs.where((j) => j['isUrgent'] == true).toList();
    }
    if (_selectedFilter == 3) {
      // High Pay — sort by budget descending
      final sorted = List<Map<String, dynamic>>.from(_jobs);
      sorted.sort((a, b) {
        final aB = _parseBudget(a['budget']);
        final bB = _parseBudget(b['budget']);
        return bB.compareTo(aB);
      });
      return sorted;
    }
    return _jobs;
  }

  int _parseBudget(dynamic value) {
    final cleaned = value.toString().replaceAll(RegExp(r'[^0-9]'), '');
    return int.tryParse(cleaned) ?? 0;
  }

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    if (mounted) setState(() => _isLoading = true);
    final hasNet = await ConnectivityService.hasInternet();
    if (!hasNet) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    final userId = AuthService.getCurrentUserId();
    if (userId == null) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    try {
      final profile = await DatabaseService.getProviderProfile(userId);
      final name =
          profile?['displayName'] ??
          AuthService.getCurrentUserDisplayName() ??
          'Provider';
      final parts = name.split(' ');
      final initials = parts.length >= 2
          ? '${parts.first[0]}${parts.last[0]}'.toUpperCase()
          : name.isNotEmpty
          ? name[0].toUpperCase()
          : 'P';
      final specialty =
          profile?['serviceType'] ?? profile?['specialty'] ?? '';
      final location = profile?['location'] ?? profile?['address'] ?? '';

      // Load jobs filtered by this provider's specialty
      final jobs = specialty.isNotEmpty
          ? await DatabaseService.getOpenRequests(category: specialty)
          : await DatabaseService.getOpenRequests();

      // Load real stats
      final stats = await DatabaseService.getProviderStats(userId);
      final totalEarnings = (stats['totalEarnings'] ?? 0).toDouble();
      final earningsStr = totalEarnings >= 1000
          ? '৳${(totalEarnings / 1000).toStringAsFixed(1)}k'
          : '৳${totalEarnings.toInt()}';

      if (mounted) {
        setState(() {
          _providerName = name;
          _providerInitials = initials;
          _providerLocation = location.toString();
          _providerSpecialty = specialty.toString();
          _jobs = jobs;
          _todayJobs = stats['activeJobs'] ?? 0;
          _monthJobs = stats['totalJobs'] ?? 0;
          _earnings = earningsStr;
        });
      }
    } catch (_) {
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  IconData _categoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'electrician':
        return Icons.bolt_rounded;
      case 'plumber':
        return Icons.plumbing_rounded;
      case 'cleaner':
        return Icons.cleaning_services_rounded;
      case 'painter':
        return Icons.format_paint_rounded;
      default:
        return Icons.work_rounded;
    }
  }

  Color _categoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'electrician':
        return const Color(0xFFC8880A);
      case 'plumber':
        return const Color(0xFF1A5A7A);
      case 'cleaner':
        return const Color(0xFF4A1A7A);
      case 'painter':
        return const Color(0xFF7A1A1A);
      default:
        return AppColors.navy;
    }
  }

  Color _categoryBg(String category) {
    switch (category.toLowerCase()) {
      case 'electrician':
        return const Color(0xFFFAF3E0);
      case 'plumber':
        return const Color(0xFFE6F1F7);
      case 'cleaner':
        return const Color(0xFFEFE6F7);
      case 'painter':
        return const Color(0xFFF7E6E6);
      default:
        return AppColors.navyLight;
    }
  }

  void _toggleOnline() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: _isOnline
                    ? const Color(0xFFFFEEEE)
                    : AppColors.successBg,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                _isOnline ? Icons.wifi_off_rounded : Icons.wifi_rounded,
                size: 18,
                color: _isOnline ? const Color(0xFFD94040) : AppColors.success,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              _isOnline ? 'Go Offline?' : 'Go Online?',
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
          ],
        ),
        content: Text(
          _isOnline
              ? 'You will stop receiving new job requests while offline. You can go back online anytime.'
              : 'You will start receiving job requests from clients near you.',
          style: const TextStyle(
            fontSize: 14,
            color: AppColors.textSecondary,
            height: 1.5,
          ),
        ),
        actionsPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
        actions: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.navyLight,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: const Text(
                'Cancel',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () async {
              final newStatus = !_isOnline;
              setState(() => _isOnline = newStatus);
              Navigator.pop(context);
              // Save online status to Firestore
              final userId = AuthService.getCurrentUserId();
              if (userId != null) {
                try {
                  await DatabaseService.setUserStatus(
                    userId: userId,
                    isOnline: newStatus,
                  );
                } catch (_) {}
              }
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              decoration: BoxDecoration(
                color: _isOnline ? const Color(0xFFD94040) : AppColors.success,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _isOnline ? 'Go Offline' : 'Go Online',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.accent),
      );
    }
    return RefreshIndicator(
      onRefresh: _loadData,
      child: CustomScrollView(
        slivers: [
          // Header
          SliverToBoxAdapter(
            child: Container(
              color: AppColors.accent,
              padding: EdgeInsets.fromLTRB(
                20,
                MediaQuery.of(context).padding.top + 14,
                20,
                20,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      ProviderAvatar(initials: _providerInitials, size: 40),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Welcome back,',
                            style: TextStyle(
                              color: Colors.black.withOpacity(0.55),
                              fontSize: 11,
                            ),
                          ),
                          Text(
                            _providerName,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -0.3,
                            ),
                          ),
                          if (_providerSpecialty.trim().isNotEmpty)
                            Text(
                              _providerSpecialty,
                              style: TextStyle(
                                color: Colors.black.withOpacity(0.65),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.2,
                              ),
                            ),
                        ],
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: _toggleOnline,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: _isOnline
                                ? AppColors.success
                                : AppColors.textTertiary,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.circle,
                                size: 7,
                                color: _isOnline
                                    ? Colors.white
                                    : Colors.white.withOpacity(0.7),
                              ),
                              const SizedBox(width: 5),
                              Text(
                                _isOnline ? 'ONLINE' : 'OFFLINE',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // KPI strip
                  Row(
                    children: [
                      _KpiTile(label: "Today's Jobs", value: '$_todayJobs'),
                      Container(
                        width: 1,
                        height: 28,
                        color: Colors.black.withOpacity(0.1),
                        margin: const EdgeInsets.symmetric(horizontal: 16),
                      ),
                      _KpiTile(label: 'This Month', value: '$_monthJobs'),
                      Container(
                        width: 1,
                        height: 28,
                        color: Colors.black.withOpacity(0.1),
                        margin: const EdgeInsets.symmetric(horizontal: 16),
                      ),
                      _KpiTile(label: 'Earnings', value: _earnings),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Filter tabs
                  SizedBox(
                    height: 30,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: ['All Jobs', 'Nearby', 'Urgent', 'High Pay']
                          .asMap()
                          .entries
                          .map(
                            (e) => GestureDetector(
                              onTap: () =>
                                  setState(() => _selectedFilter = e.key),
                              child: Container(
                                margin: const EdgeInsets.only(right: 8),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 5,
                                ),
                                decoration: BoxDecoration(
                                  color: e.key == _selectedFilter
                                      ? Colors.white
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(4),
                                  border: Border.all(
                                    color: e.key == _selectedFilter
                                        ? Colors.white
                                        : Colors.black.withOpacity(0.2),
                                  ),
                                ),
                                child: Text(
                                  e.value,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: e.key == _selectedFilter
                                        ? AppColors.accent
                                        : Colors.black.withOpacity(0.75),
                                  ),
                                ),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Offline banner
          if (!_isOnline)
            SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF3E0),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange.withOpacity(0.4)),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.wifi_off_rounded,
                      size: 16,
                      color: Colors.orange,
                    ),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'You are offline. Tap OFFLINE to go back online and receive job requests.',
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xFF7A4500),
                          height: 1.4,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _toggleOnline,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.success,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text(
                          'Go Online',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Section label
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
              child: SectionHeader(
                title: 'Available Requests (${_filteredJobs.length})',
                action: 'Refresh',
                onAction: () => _loadData(),
              ),
            ),
          ),

          // Job cards
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate((context, i) {
                final job = _filteredJobs[i];
                final isUrgent = job['isUrgent'] == true;
                final category = (job['category'] ?? '') as String;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isUrgent
                            ? AppColors.urgent.withOpacity(0.4)
                            : AppColors.border,
                        width: isUrgent ? 1.5 : 1,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: _categoryBg(category),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      _categoryIcon(category),
                                      color: _categoryColor(category),
                                      size: 18,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          category,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w700,
                                            fontSize: 14,
                                            color: AppColors.textPrimary,
                                          ),
                                        ),
                                        Text(
                                          'Posted by ${job['clientId'] ?? 'Client'}',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontSize: 11,
                                            color: AppColors.textTertiary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  if (isUrgent)
                                    StatusBadge(
                                      label: 'URGENT',
                                      color: AppColors.urgent,
                                      bgColor: AppColors.urgentBg,
                                      icon: Icons.bolt_rounded,
                                    ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                (job['description'] ?? '') as String,
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: AppColors.textSecondary,
                                  height: 1.55,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: const BoxDecoration(
                            color: AppColors.surfaceAlt,
                            borderRadius: BorderRadius.vertical(
                              bottom: Radius.circular(10),
                            ),
                            border: Border(
                              top: BorderSide(color: AppColors.divider),
                            ),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.location_on_outlined,
                                      size: 12,
                                      color: AppColors.textTertiary,
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        '${job['location'] ?? 'Location not set'}',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 11,
                                          color: AppColors.textTertiary,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                '৳${job['budget'] ?? '0'}',
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.navy,
                                ),
                              ),
                              const SizedBox(width: 10),
                              SizedBox(
                                height: 30,
                                child: ElevatedButton(
                                  onPressed: () async {
                                    final providerId =
                                        AuthService.getCurrentUserId();
                                    if (providerId == null) return;
                                    final requestId = job['id'] ?? '';
                                    final clientId = job['clientId'] ?? '';
                                    final budget = job['budget'] ?? '';

                                    final hasNet =
                                        await ConnectivityService.hasInternet();
                                    if (!hasNet) {
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              'No internet connection',
                                            ),
                                          ),
                                        );
                                      }
                                      return;
                                    }

                                    try {
                                      await DatabaseService.createBooking(
                                        requestId: requestId,
                                        clientId: clientId,
                                        providerId: providerId,
                                        agreedPrice: budget,
                                      );
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              'Job accepted successfully!',
                                            ),
                                            backgroundColor: AppColors.success,
                                          ),
                                        );
                                        // Refresh the jobs list
                                        _loadData();
                                      }
                                    } catch (e) {
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              'Failed to accept: ${e.toString().replaceAll("Exception: ", "")}',
                                            ),
                                          ),
                                        );
                                      }
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: isUrgent
                                        ? AppColors.urgent
                                        : AppColors.accent,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                    ),
                                  ),
                                  child: Text(
                                    isUrgent ? 'Accept Now' : 'Accept',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }, childCount: _filteredJobs.length),
            ),
          ),
        ],
      ),
    );
  }
}

class _KpiTile extends StatelessWidget {
  final String label;
  final String value;
  const _KpiTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        value,
        style: const TextStyle(
          color: Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.3,
        ),
      ),
      Text(
        label,
        style: TextStyle(
          color: Colors.black.withOpacity(0.5),
          fontSize: 10,
          fontWeight: FontWeight.w500,
        ),
      ),
    ],
  );
}

// ─── My Jobs ──────────────────────────────────────────────────────────────────

class _MyJobsScreen extends StatefulWidget {
  const _MyJobsScreen();
  @override
  State<_MyJobsScreen> createState() => _MyJobsScreenState();
}

class _MyJobsScreenState extends State<_MyJobsScreen> {
  List<Map<String, dynamic>> _bookings = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadBookings();
  }

  Future<void> _loadBookings() async {
    if (mounted) setState(() => _loading = true);
    final userId = AuthService.getCurrentUserId();
    if (userId == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final raw = await DatabaseService.getProviderBookings(userId);
      // Show only bookings the provider has accepted (exclude pending).
      final accepted = raw
          .where((b) => (b['status'] ?? '') != 'pending')
          .toList();

      final enriched = <Map<String, dynamic>>[];
      for (final b in accepted) {
        final requestId = (b['requestId'] ?? '').toString();
        final clientId = (b['clientId'] ?? '').toString();

        Map<String, dynamic>? request;
        if (requestId.isNotEmpty) {
          request = await DatabaseService.getServiceRequest(requestId);
        }

        String clientName = 'Client';
        if (clientId.isNotEmpty) {
          final clientData = await DatabaseService.getClientProfile(clientId);
          clientName = (clientData?['displayName'] ?? 'Client').toString();
        }

        enriched.add({
          ...b,
          'category': request?['category'] ?? '',
          'description': request?['description'] ?? '',
          'location': request?['location'] ?? '',
          'isUrgent': request?['isUrgent'] ?? false,
          'clientName': clientName,
        });
      }

      if (mounted) {
        setState(() {
          _bookings = enriched;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  IconData _categoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'electrician':
        return Icons.bolt_rounded;
      case 'plumber':
        return Icons.plumbing_rounded;
      case 'cleaner':
        return Icons.cleaning_services_rounded;
      case 'painter':
        return Icons.format_paint_rounded;
      default:
        return Icons.work_rounded;
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(
      title: const Text('My Jobs'),
      backgroundColor: AppColors.accent,
      foregroundColor: Colors.black,
      automaticallyImplyLeading: false,
    ),
    body: _loading
        ? const Center(
            child: CircularProgressIndicator(color: AppColors.accent),
          )
        : _bookings.isEmpty
        ? const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.work_outline_rounded,
                  size: 52,
                  color: AppColors.textTertiary,
                ),
                SizedBox(height: 14),
                Text(
                  'No active jobs',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Accepted jobs will appear here',
                  style: TextStyle(fontSize: 13, color: AppColors.textTertiary),
                ),
              ],
            ),
          )
        : RefreshIndicator(
            onRefresh: _loadBookings,
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _bookings.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final b = _bookings[i];
                final status = (b['status'] ?? 'pending').toString();
                final price = (b['agreedPrice'] ?? '').toString();
                final category = (b['category'] ?? '').toString();
                final clientName = (b['clientName'] ?? 'Client').toString();
                final location = (b['location'] ?? '').toString();
                final description = (b['description'] ?? '').toString();
                final isUrgent = b['isUrgent'] == true;
                final displayTitle = category.isNotEmpty
                    ? category
                    : 'Booking #${(b['id'] ?? '').toString().substring(0, 6)}';
                final statusColor = status == 'completed'
                    ? AppColors.success
                    : status == 'in_progress'
                    ? AppColors.accent
                    : AppColors.navy;
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isUrgent
                          ? AppColors.urgent.withOpacity(0.4)
                          : AppColors.border,
                      width: isUrgent ? 1.5 : 1,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: AppColors.accentLight,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              _categoryIcon(category),
                              size: 20,
                              color: AppColors.accent,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  displayTitle,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Client: $clientName',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (isUrgent)
                            const StatusBadge(
                              label: 'URGENT',
                              color: AppColors.urgent,
                              bgColor: AppColors.urgentBg,
                              icon: Icons.bolt_rounded,
                            ),
                        ],
                      ),
                      if (description.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Text(
                          description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 13,
                            color: AppColors.textSecondary,
                            height: 1.45,
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          if (location.isNotEmpty) ...[
                            const Icon(
                              Icons.location_on_outlined,
                              size: 13,
                              color: AppColors.textTertiary,
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                location,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: AppColors.textTertiary,
                                ),
                              ),
                            ),
                          ] else
                            const Spacer(),
                          if (price.isNotEmpty)
                            Text(
                              '৳$price',
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: AppColors.navy,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              status.toUpperCase(),
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                color: statusColor,
                                letterSpacing: 0.4,
                              ),
                            ),
                          ),
                          const Spacer(),
                          if (status == 'pending' || status == 'confirmed')
                            SizedBox(
                              height: 30,
                              child: ElevatedButton(
                                onPressed: () async {
                                  final newStatus = status == 'pending'
                                      ? 'confirmed'
                                      : 'in_progress';
                                  await DatabaseService.updateBookingStatus(
                                    bookingId: b['id'],
                                    status: newStatus,
                                  );
                                  _loadBookings();
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.success,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                  ),
                                ),
                                child: Text(
                                  status == 'pending' ? 'Confirm' : 'Start',
                                  style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          if (status == 'in_progress')
                            SizedBox(
                              height: 30,
                              child: ElevatedButton(
                                onPressed: () async {
                                  await DatabaseService.updateBookingStatus(
                                    bookingId: b['id'],
                                    status: 'completed',
                                  );
                                  _loadBookings();
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.success,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                  ),
                                ),
                                child: const Text(
                                  'Complete',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
  );
}

// ─── Chats ────────────────────────────────────────────────────────────────────

class _ChatsScreen extends StatefulWidget {
  const _ChatsScreen();
  @override
  State<_ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<_ChatsScreen> {
  List<Map<String, dynamic>> _conversations = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadConversations();
  }

  Future<void> _loadConversations() async {
    final userId = AuthService.getCurrentUserId();
    if (userId == null) {
      setState(() => _loading = false);
      return;
    }
    try {
      final convs = await DatabaseService.getUserConversations(userId, false);
      List<Map<String, dynamic>> enriched = [];
      for (final conv in convs) {
        final clientId = conv['clientId'] ?? '';
        Map<String, dynamic>? clientData;
        if (clientId.isNotEmpty) {
          clientData = await DatabaseService.getClientProfile(clientId);
        }
        final name = clientData?['displayName'] ?? 'Client';
        final parts = name.split(' ');
        final initials = parts.length >= 2
            ? '${parts.first[0]}${parts.last[0]}'.toUpperCase()
            : name.isNotEmpty
            ? name[0].toUpperCase()
            : 'C';
        enriched.add({...conv, '_name': name, '_initials': initials});
      }
      if (mounted)
        setState(() {
          _conversations = enriched;
          _loading = false;
        });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(
      title: const Text('Messages'),
      backgroundColor: AppColors.accent,
      foregroundColor: Colors.black,
      automaticallyImplyLeading: false,
    ),
    body: _loading
        ? const Center(
            child: CircularProgressIndicator(color: AppColors.accent),
          )
        : _conversations.isEmpty
        ? const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.chat_bubble_outline_rounded,
                  size: 52,
                  color: AppColors.textTertiary,
                ),
                SizedBox(height: 14),
                Text(
                  'No messages yet',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Client messages will appear here',
                  style: TextStyle(fontSize: 13, color: AppColors.textTertiary),
                ),
              ],
            ),
          )
        : RefreshIndicator(
            onRefresh: _loadConversations,
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _conversations.length,
              itemBuilder: (context, i) {
                final c = _conversations[i];
                return GestureDetector(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChatScreen(
                        conversationId: c['id'] ?? '',
                        otherUserName: c['_name'] ?? 'Client',
                        otherUserInitials: c['_initials'] ?? 'C',
                      ),
                    ),
                  ),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        ProviderAvatar(
                          initials: c['_initials'] ?? 'C',
                          size: 44,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                c['_name'] ?? 'Client',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 3),
                              const Text(
                                'Tap to continue chat',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: AppColors.textSecondary,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
  );
}
